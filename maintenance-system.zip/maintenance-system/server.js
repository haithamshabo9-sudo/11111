require('dotenv').config();
const express = require('express');
const path = require('path');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error('JWT_SECRET مفقود أو قصير (32 حرفاً على الأقل) في ملف .env'); process.exit(1);
}
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const q = (s, p) => pool.query(s, p);
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const wrap = f => (req, res) => f(req, res).catch(e => { console.error(e); res.status(500).json({ error: 'خطأ في الخادم' }); });
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const pub = u => ({ id: u.id, name: u.name, username: u.username, role: u.role, dept_id: u.dept_id });
const str = (v, max) => String(v ?? '').trim().slice(0, max);
const STAFF = ['tech', 'supervisor'];

// التحقق من الهوية في كل طلب، ومن قاعدة البيانات (الحساب المعطّل يفقد الوصول فوراً)
const auth = wrap(async (req, res, next) => {
  let id;
  try { id = jwt.verify((req.headers.authorization || '').slice(7), process.env.JWT_SECRET).id; }
  catch { return bad(res, 'سجّل الدخول', 401); }
  const { rows: [u] } = await q('SELECT * FROM users WHERE id=$1 AND active', [id]);
  if (!u) return bad(res, 'سجّل الدخول', 401);
  req.u = u; next();
});
const only = (...roles) => (req, res, next) => roles.includes(req.u.role) ? next() : bad(res, 'غير مصرح', 403);

// نطاق الرؤية يُفرض هنا على الخادم وليس في الواجهة
const scope = u =>
  u.role === 'admin' ? ['true', []] :
  u.role === 'requester' ? ['t.requester_id=$1', [u.id]] : ['t.dept_id=$1', [u.dept_id]];
const SEL = `SELECT t.*, d.name dept, r.name requester, x.name tech
  FROM tickets t JOIN departments d ON d.id=t.dept_id JOIN users r ON r.id=t.requester_id
  LEFT JOIN users x ON x.id=t.tech_id`;

const notifyDept = (tid, dept, text, except) => q(
  `INSERT INTO notifications(user_id,ticket_id,text) SELECT id,$1,$2 FROM users
   WHERE dept_id=$3 AND role IN ('tech','supervisor') AND active AND id<>$4`, [tid, text, dept, except || 0]);
const notifyUser = (tid, uid, text) => uid && q('INSERT INTO notifications(user_id,ticket_id,text) VALUES($1,$2,$3)', [uid, tid, text]);
const addLog = (tid, uid, text) => q('INSERT INTO ticket_log(ticket_id,user_id,text) VALUES($1,$2,$3)', [tid, uid, text]);

// ---- الدخول ----
app.post('/api/login', rateLimit({ windowMs: 15 * 60e3, max: 20, standardHeaders: true, legacyHeaders: false }),
  wrap(async (req, res) => {
    const { rows: [u] } = await q('SELECT * FROM users WHERE username=$1 AND active', [str(req.body.username, 60)]);
    const ok = u && await bcrypt.compare(String(req.body.password ?? ''), u.password_hash);
    if (!ok) return bad(res, 'اسم المستخدم أو كلمة المرور غير صحيحة', 401);
    res.json({ token: jwt.sign({ id: u.id }, process.env.JWT_SECRET, { expiresIn: '8h' }), user: pub(u) });
  }));
app.get('/api/me', auth, (req, res) => res.json(pub(req.u)));
app.get('/api/departments', auth, wrap(async (req, res) => res.json((await q('SELECT * FROM departments ORDER BY id')).rows)));

// ---- الطلبات ----
app.get('/api/tickets', auth, wrap(async (req, res) => {
  const [w, p] = scope(req.u);
  res.json((await q(`${SEL} WHERE ${w} ORDER BY (t.priority='critical' AND t.status<>'done') DESC, t.created_at DESC LIMIT 500`, p)).rows);
}));

app.get('/api/tickets/:id', auth, wrap(async (req, res) => {
  const [w, p] = scope(req.u);
  const { rows: [t] } = await q(`${SEL} WHERE ${w} AND t.id=$2`, [...p, +req.params.id || 0]);
  if (!t) return bad(res, 'الطلب غير موجود', 404);
  const log = (await q('SELECT l.text,l.at,u.name FROM ticket_log l LEFT JOIN users u ON u.id=l.user_id WHERE ticket_id=$1 ORDER BY l.id', [t.id])).rows;
  res.json({ t, log });
}));

app.post('/api/tickets', auth, wrap(async (req, res) => {
  const b = req.body, dept = +b.dept_id, pr = b.priority;
  const location = str(b.location, 200), device = str(b.device, 150), description = str(b.description, 2000);
  if (!location || !device || !description) return bad(res, 'أدخل الموقع واسم الجهاز ووصف المشكلة');
  if (!['normal', 'urgent', 'critical'].includes(pr)) return bad(res, 'أولوية غير صحيحة');
  if (!(await q('SELECT 1 FROM departments WHERE id=$1', [dept])).rowCount) return bad(res, 'شعبة غير صحيحة');
  const { rows: [t] } = await q(
    `INSERT INTO tickets(no,requester_id,dept_id,location,device,description,priority)
     VALUES('MNT-'||extract(year from now())::int||'-'||lpad(nextval('ticket_seq')::text,4,'0'),$1,$2,$3,$4,$5,$6)
     RETURNING id,no`, [req.u.id, dept, location, device, description, pr]);
  await addLog(t.id, req.u.id, 'تم إنشاء الطلب');
  await notifyDept(t.id, dept, `طلب جديد ${t.no} (${{ normal: 'عادي', urgent: 'مستعجل', critical: 'حرج' }[pr]}): ${device}`, req.u.id);
  res.status(201).json(t);
}));

app.post('/api/tickets/:id/action', auth, wrap(async (req, res) => {
  const u = req.u, id = +req.params.id || 0, { action } = req.body;
  const text = str(req.body.text, 2000), parts = str(req.body.parts, 500);
  const { rows: [t] } = await q('SELECT * FROM tickets WHERE id=$1', [id]);
  if (!t) return bad(res, 'الطلب غير موجود', 404);
  const inDept = STAFF.includes(u.role) && u.dept_id === t.dept_id;
  const sup = inDept && u.role === 'supervisor', mine = t.tech_id === u.id;
  const run = async (sql, p) => (await q(sql, p)).rowCount;
  let ok = 0, logText, toRequester, toDept, toTech;

  if (action === 'take') {
    if (!inDept) return bad(res, 'غير مصرح', 403);
    // شرط الحالة داخل UPDATE يمنع استلام الطلب من فنيين في اللحظة نفسها
    ok = await run(`UPDATE tickets SET status='received',tech_id=$2,received_at=now() WHERE id=$1 AND status='new' AND tech_id IS NULL`, [id, u.id]);
    if (!ok) return bad(res, 'الطلب استُلم مسبقاً', 409);
    logText = 'استلم المهمة: ' + u.name; toRequester = `${t.no}: استلم الفني ${u.name} طلبك`;
  } else if (action === 'start') {
    if (!(inDept && (mine || sup))) return bad(res, 'غير مصرح', 403);
    ok = await run(`UPDATE tickets SET status='progress',started_at=COALESCE(started_at,now()) WHERE id=$1 AND status IN ('received','paused')`, [id]);
    logText = 'بدء العمل'; toRequester = `${t.no}: بدأ العمل على الطلب`;
  } else if (action === 'pause') {
    if (!(inDept && (mine || sup))) return bad(res, 'غير مصرح', 403);
    if (!text) return bad(res, 'اكتب سبب التوقف');
    ok = await run(`UPDATE tickets SET status='paused' WHERE id=$1 AND status IN ('received','progress')`, [id]);
    logText = 'توقف مؤقت: ' + text; toRequester = `${t.no}: متوقف مؤقتاً — ${text}`; toDept = toRequester;
  } else if (action === 'done') {
    if (!(inDept && (mine || sup))) return bad(res, 'غير مصرح', 403);
    if (!text) return bad(res, 'تقرير الإنجاز إلزامي');
    ok = await run(`UPDATE tickets SET status='done',report=$2,parts=$3,done_at=now(),tech_id=COALESCE(tech_id,$4) WHERE id=$1 AND status IN ('received','progress')`, [id, text, parts || null, u.id]);
    logText = 'أُنجزت الصيانة وأُغلق الطلب'; toRequester = `${t.no}: اكتملت الصيانة`;
  } else if (action === 'reopen') {
    if (!(t.requester_id === u.id || sup)) return bad(res, 'غير مصرح', 403);
    ok = await run(`UPDATE tickets SET status='new',tech_id=NULL,report=NULL,parts=NULL,done_at=NULL,received_at=NULL,started_at=NULL WHERE id=$1 AND status='done'`, [id]);
    logText = 'أُعيد فتح الطلب' + (text ? ': ' + text : ''); toDept = `${t.no}: أُعيد فتح الطلب`;
  } else if (action === 'assign') {
    const tech = +req.body.tech || 0;
    if (!sup) return bad(res, 'غير مصرح', 403);
    const { rows: [x] } = await q(`SELECT id,name FROM users WHERE id=$1 AND role='tech' AND dept_id=$2 AND active`, [tech, t.dept_id]);
    if (!x) return bad(res, 'فني غير صحيح');
    ok = await run(`UPDATE tickets SET tech_id=$2,status=CASE WHEN status='new' THEN 'received' ELSE status END,received_at=COALESCE(received_at,now()) WHERE id=$1 AND status<>'done'`, [id, tech]);
    logText = 'أُسند الطلب إلى ' + x.name; toTech = [tech, `أُسند إليك الطلب ${t.no}`];
  } else return bad(res, 'إجراء غير معروف');

  if (!ok) return bad(res, 'هذا الإجراء غير متاح في حالة الطلب الحالية', 409);
  await addLog(id, u.id, logText);
  if (toRequester && t.requester_id !== u.id) await notifyUser(id, t.requester_id, toRequester);
  if (toDept) await notifyDept(id, t.dept_id, toDept, u.id);
  if (toTech) await notifyUser(id, ...toTech);
  res.json({ ok: true });
}));

// ---- الإشعارات (الواجهة تستعلم كل 20 ثانية؛ الدفع إلى الهاتف يُضاف لاحقاً) ----
app.get('/api/notifications', auth, wrap(async (req, res) => {
  const list = (await q('SELECT * FROM notifications WHERE user_id=$1 ORDER BY id DESC LIMIT 50', [req.u.id])).rows;
  const unread = (await q('SELECT count(*)::int n FROM notifications WHERE user_id=$1 AND NOT read', [req.u.id])).rows[0].n;
  res.json({ list, unread });
}));
app.post('/api/notifications/read', auth, wrap(async (req, res) => {
  await q('UPDATE notifications SET read=true WHERE user_id=$1 AND NOT read', [req.u.id]); res.json({ ok: true });
}));

// ---- إدارة المستخدمين والإحصائيات (المدير فقط) ----
app.get('/api/dept-techs', auth, only('supervisor'), wrap(async (req, res) =>
  res.json((await q("SELECT id,name FROM users WHERE role='tech' AND dept_id=$1 AND active ORDER BY name", [req.u.dept_id])).rows)));

app.get('/api/users', auth, only('admin'), wrap(async (req, res) =>
  res.json((await q('SELECT u.id,u.name,u.username,u.role,u.dept_id,u.active,d.name dept FROM users u LEFT JOIN departments d ON d.id=u.dept_id ORDER BY u.id')).rows)));

app.post('/api/users', auth, only('admin'), wrap(async (req, res) => {
  const name = str(req.body.name, 100), username = str(req.body.username, 60).toLowerCase(), pw = String(req.body.password ?? '');
  const role = req.body.role, dept = STAFF.includes(role) ? +req.body.dept_id || null : null;
  if (!name || !/^[a-z0-9._-]{3,}$/.test(username)) return bad(res, 'اسم المستخدم: 3 أحرف أو أكثر إنجليزية أو أرقام');
  if (pw.length < 8) return bad(res, 'كلمة المرور 8 أحرف على الأقل');
  if (!['requester', 'tech', 'supervisor', 'admin'].includes(role)) return bad(res, 'دور غير صحيح');
  if (STAFF.includes(role) && !dept) return bad(res, 'اختر الشعبة');
  try {
    const { rows: [n] } = await q('INSERT INTO users(name,username,password_hash,role,dept_id) VALUES($1,$2,$3,$4,$5) RETURNING id',
      [name, username, await bcrypt.hash(pw, 12), role, dept]);
    res.status(201).json(n);
  } catch (e) { if (e.code === '23505') return bad(res, 'اسم المستخدم مستخدم مسبقاً', 409); throw e; }
}));

app.patch('/api/users/:id', auth, only('admin'), wrap(async (req, res) => {
  const id = +req.params.id || 0;
  if (typeof req.body.active === 'boolean') {
    if (id === req.u.id) return bad(res, 'لا يمكنك تعطيل حسابك');
    await q('UPDATE users SET active=$2 WHERE id=$1', [id, req.body.active]);
  }
  if (req.body.password !== undefined) {
    if (String(req.body.password).length < 8) return bad(res, 'كلمة المرور 8 أحرف على الأقل');
    await q('UPDATE users SET password_hash=$2 WHERE id=$1', [id, await bcrypt.hash(String(req.body.password), 12)]);
  }
  res.json({ ok: true });
}));

app.get('/api/stats', auth, only('admin'), wrap(async (req, res) => {
  const byStatus = (await q('SELECT status,count(*)::int n FROM tickets GROUP BY status')).rows;
  const byDept = (await q(`SELECT d.name,count(t.id)::int total,count(t.id) FILTER (WHERE t.status<>'done')::int open
    FROM departments d LEFT JOIN tickets t ON t.dept_id=d.id GROUP BY d.id ORDER BY d.id`)).rows;
  const { rows: [m] } = await q(`SELECT round(avg(extract(epoch FROM done_at-created_at)/60))::int avg_done,
    round(avg(extract(epoch FROM received_at-created_at)/60))::int avg_resp,
    count(*) FILTER (WHERE status='new' AND created_at<now()-interval '1 hour')::int unreceived FROM tickets`);
  res.json({ byStatus, byDept, ...m });
}));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log('يعمل على المنفذ ' + port));
