// ينشئ حساب مدير النظام الأول: npm run seed
require('dotenv').config();
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
(async () => {
  const pw = process.env.ADMIN_PASSWORD || '';
  if (pw.length < 8) { console.error('ضع ADMIN_PASSWORD (8 أحرف على الأقل) في ملف .env'); process.exit(1); }
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const un = process.env.ADMIN_USERNAME || 'admin';
  const hash = await bcrypt.hash(pw, 12);
  await pool.query(
    `INSERT INTO users(name,username,password_hash,role) VALUES('مدير النظام',$1,$2,'admin')
     ON CONFLICT (username) DO NOTHING`, [un, hash]);
  console.log('تم. سجّل الدخول باسم المستخدم:', un);
  await pool.end();
})().catch(e => { console.error(e.message); process.exit(1); });
