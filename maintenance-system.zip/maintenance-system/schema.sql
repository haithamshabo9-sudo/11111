-- نفّذه مرة واحدة: psql -U maint_user -d maintenance -f schema.sql
CREATE TABLE IF NOT EXISTS departments (
  id   SERIAL PRIMARY KEY,
  name TEXT UNIQUE NOT NULL
);
INSERT INTO departments(name) VALUES
 ('شعبة الحاسب'),('دائرة التجهيزات الطبية'),('دائرة التيار الضعيف'),('دائرة التيار القوي'),
 ('دائرة الميكانيك'),('دائرة الصيانة'),('دائرة الصيانة الفنية')
ON CONFLICT (name) DO NOTHING;

CREATE TABLE IF NOT EXISTS users (
  id            SERIAL PRIMARY KEY,
  name          TEXT NOT NULL,
  username      TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL CHECK (role IN ('requester','tech','supervisor','admin')),
  dept_id       INT REFERENCES departments(id),
  active        BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (role NOT IN ('tech','supervisor') OR dept_id IS NOT NULL)
);

CREATE SEQUENCE IF NOT EXISTS ticket_seq;
CREATE TABLE IF NOT EXISTS tickets (
  id           SERIAL PRIMARY KEY,
  no           TEXT UNIQUE NOT NULL,
  requester_id INT NOT NULL REFERENCES users(id),
  dept_id      INT NOT NULL REFERENCES departments(id),
  location     TEXT NOT NULL,
  device       TEXT NOT NULL,
  description  TEXT NOT NULL,
  priority     TEXT NOT NULL CHECK (priority IN ('normal','urgent','critical')),
  status       TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','received','progress','paused','done')),
  tech_id      INT REFERENCES users(id),
  report       TEXT,
  parts        TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  received_at  TIMESTAMPTZ,
  started_at   TIMESTAMPTZ,
  done_at      TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS tickets_dept_status ON tickets(dept_id, status);
CREATE INDEX IF NOT EXISTS tickets_requester  ON tickets(requester_id);

CREATE TABLE IF NOT EXISTS ticket_log (
  id        SERIAL PRIMARY KEY,
  ticket_id INT NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  user_id   INT REFERENCES users(id),
  text      TEXT NOT NULL,
  at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS notifications (
  id        SERIAL PRIMARY KEY,
  user_id   INT NOT NULL REFERENCES users(id),
  ticket_id INT REFERENCES tickets(id) ON DELETE CASCADE,
  text      TEXT NOT NULL,
  read      BOOLEAN NOT NULL DEFAULT false,
  at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS notif_user ON notifications(user_id, read);
